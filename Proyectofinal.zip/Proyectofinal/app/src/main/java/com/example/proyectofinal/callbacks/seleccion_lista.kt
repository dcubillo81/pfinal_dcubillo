package com.example.proyectofinal.callbacks

import com.example.proyectofinal.modelos.data_pokemon

interface seleccion_lista {
    fun click_lista(datos: data_pokemon)
}