package com.example.proyectofinal.fragments

import android.os.Bundle
import androidx.fragment.app.Fragment
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import androidx.navigation.fragment.findNavController
import androidx.recyclerview.widget.DividerItemDecoration
import androidx.recyclerview.widget.DividerItemDecoration.VERTICAL
import com.example.proyectofinal.R
import com.example.proyectofinal.callbacks.seleccion_lista
import com.example.proyectofinal.modelos.data_pokemon
import com.example.proyectofinal.view_holder.adapter_lista
import kotlinx.android.synthetic.main.fragment_lista_pokemon.*


class lista_pokemon : Fragment() , seleccion_lista  {

    private val adapter = adapter_lista(this)


    override fun onCreateView(inflater: LayoutInflater, container: ViewGroup?,
                              savedInstanceState: Bundle?): View? {
        // Inflate the layout for this fragment
        return inflater.inflate(R.layout.fragment_lista_pokemon, container, false)
    }

    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        super.onViewCreated(view, savedInstanceState)

        recycler_pokemones.adapter = adapter
        recycler_pokemones.addItemDecoration(DividerItemDecoration(requireContext(), VERTICAL))

        adapter.datos_prueba=datosfalsos()

    }

    private fun datosfalsos() : List<data_pokemon> {
        return listOf(
            data_pokemon("Sazabi","https://picsum.photos/200",true),
            data_pokemon("Unicorn","https://picsum.photos/200",true),
            data_pokemon("Kampfer","https://picsum.photos/200",true),
            data_pokemon("Strike","https://picsum.photos/200",false),
            data_pokemon("Sinanju","https://picsum.photos/200",false),
            data_pokemon("Freedom G","https://picsum.photos/200",false),
            data_pokemon("Hi V","https://picsum.photos/200",false),
            data_pokemon("Tieren","https://picsum.photos/200",true),
            data_pokemon("RX-78-5","https://picsum.photos/200",true)

        )


    }

    override fun click_lista(datos: data_pokemon) {
        findNavController().navigate(R.id.action_lista_pokemon_to_pokemon_detalle)
    }

}