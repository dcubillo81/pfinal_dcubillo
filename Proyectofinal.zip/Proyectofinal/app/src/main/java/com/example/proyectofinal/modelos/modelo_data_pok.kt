package com.example.proyectofinal.modelos

data class data_pokemon(val nom_pokemon: String, val url_foto: String, val favorito: Boolean)
