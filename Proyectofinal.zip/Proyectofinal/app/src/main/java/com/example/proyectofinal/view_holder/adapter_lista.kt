package com.example.proyectofinal.view_holder

import android.view.LayoutInflater
import android.view.ViewGroup
import androidx.recyclerview.widget.RecyclerView
import com.example.proyectofinal.R
import com.example.proyectofinal.callbacks.seleccion_lista
import com.example.proyectofinal.modelos.data_pokemon

class adapter_lista(val listener:seleccion_lista) : RecyclerView.Adapter<view_holder_list>() {

    var datos_prueba :List<data_pokemon> = emptyList()
    set(value) {
        field = value
        notifyDataSetChanged()
    }


    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): view_holder_list {
        val view = LayoutInflater.from(parent.context).inflate(R.layout.pokemon_list_item,parent,false)
        return view_holder_list(view)
    }

    override fun onBindViewHolder(holder: view_holder_list, position: Int) {
        holder.bind(datos_prueba[position], listener)
    }

    override fun getItemCount(): Int {
        return datos_prueba.size
    }

}