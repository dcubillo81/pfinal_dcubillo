package com.example.proyectofinal.view_holder

import android.view.View
import androidx.recyclerview.widget.RecyclerView
import com.bumptech.glide.Glide
import com.example.proyectofinal.R
import com.example.proyectofinal.callbacks.seleccion_lista
import com.example.proyectofinal.modelos.data_pokemon
import kotlinx.android.synthetic.main.pokemon_list_item.view.*

class view_holder_list(itemView: View) : RecyclerView.ViewHolder(itemView) {

    fun bind (data:data_pokemon, listener:seleccion_lista) {
        itemView.nombre_pokemon_lista.text = data.nom_pokemon

        Glide.with(itemView.context)
            .load(data.url_foto)
            .circleCrop()
            .into(itemView.imagen_pokemon)

        val isFavoriteIcon = if (data.favorito) R.drawable.ic_baseline_favorite_24 else R.drawable.ic_baseline_favorite_border_24
        itemView.imagen_favoritos_lista.setImageResource(isFavoriteIcon)
        itemView.setOnClickListener {
            listener.click_lista(data)
        }

    }

}



